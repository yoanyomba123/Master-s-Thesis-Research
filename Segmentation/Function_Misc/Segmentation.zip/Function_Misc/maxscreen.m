function [] = maxscreen()
set(gcf,'outerposition',get(0,'screensize'));
end